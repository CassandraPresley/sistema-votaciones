const interopDefault = r => r.default || r || [];
const styles = {
  "pages/index.vue": () => import('../build/index-styles.velaP7Gf.mjs').then(interopDefault),
  "pages/admin.vue": () => import('../build/admin-styles.FDKjbd-3.mjs').then(interopDefault),
  "../node_modules/nuxt/dist/app/components/error-500.vue": () => import('../build/error-500-styles.CB5z51D_.mjs').then(interopDefault),
  "../node_modules/nuxt/dist/app/components/error-404.vue": () => import('../build/error-404-styles.CbLQIMfl.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
